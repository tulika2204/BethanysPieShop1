﻿create database Inventory;
