﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public interface IBookingRepository
    {
        IEnumerable<Booking_Details> AllBooking { get; }

        Booking_Details GetBooking_DetailsById(int BookingId);
    }
}
