﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class OrderCartItems
    {[Key]
        public int OrderCartItemId { get; set; }
        public Food Food { get; set; }
        public int Amount { get; set; }
        public string OrderCartId { get; set; }
        public int FoodId { get; set; }
       // public virtual Food Foods { get; set; }
    }
}
