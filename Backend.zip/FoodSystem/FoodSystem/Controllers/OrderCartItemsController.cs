﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodSystem.Models;

namespace FoodSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderCartItemsController : ControllerBase
    {
        private readonly FoodDbContext _context;

        public OrderCartItemsController(FoodDbContext context)
        {
            _context = context;
        }

        // GET: api/OrderCartItems
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderCartItems>>> GetOrderCartItems()
        {
            return await _context.OrderCartItems.ToListAsync();
        }

        // GET: api/OrderCartItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderCartItems>> GetOrderCartItems(int id)
        {
            var orderCartItems = await _context.OrderCartItems.FindAsync(id);

            if (orderCartItems == null)
            {
                return NotFound();
            }

            return orderCartItems;
        }

        // PUT: api/OrderCartItems/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderCartItems(int id, OrderCartItems orderCartItems)
        {
            if (id != orderCartItems.OrderCartItemId)
            {
                return BadRequest();
            }

            _context.Entry(orderCartItems).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderCartItemsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OrderCartItems
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<OrderCartItems>> PostOrderCartItems(OrderCartItems orderCartItems)
        {
            _context.OrderCartItems.Add(orderCartItems);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrderCartItems", new { id = orderCartItems.OrderCartItemId }, orderCartItems);
        }

        // DELETE: api/OrderCartItems/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<OrderCartItems>> DeleteOrderCartItems(int id)
        {
            var orderCartItems = await _context.OrderCartItems.FindAsync(id);
            if (orderCartItems == null)
            {
                return NotFound();
            }

            _context.OrderCartItems.Remove(orderCartItems);
            await _context.SaveChangesAsync();

            return orderCartItems;
        }

        private bool OrderCartItemsExists(int id)
        {
            return _context.OrderCartItems.Any(e => e.OrderCartItemId == id);
        }
    }
}
