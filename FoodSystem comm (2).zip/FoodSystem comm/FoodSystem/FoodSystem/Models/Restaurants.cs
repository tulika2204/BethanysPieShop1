﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class Restaurants
    {
        [Key]
        public int RestId { get; set; }
        public string RestName { get; set; }
        public decimal RestMenu { get; set; }
        public string RestImageUrl { get; set; }

        public string RestDesc { get; set; }
        public int RestContactNumber { get; set; }
        public string Address { get; set; }
    }
}
