﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class Food
    {
        public int FoodId { get; set; }
        public string FoodName { get; set; }
        public decimal FoodPrice { get; set; }
        public string FoodImageUrl { get; set; }
        public string FoodImageThumbnailUrl { get; set; }
        public string FoodDesc { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
