﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class RestaurantsRepository:IRestaurantRepository
    {
        private readonly FoodDbContext _appDbContext;



        public RestaurantsRepository(FoodDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }



        public IEnumerable<Restaurants> AllRestaurants => _appDbContext.Restaurants;

        public Restaurants GetRestaurantsById(int RestId)
        {
            return _appDbContext.Restaurants.FirstOrDefault(r => r.RestId == RestId);
        }



    }
}



   
   



   
