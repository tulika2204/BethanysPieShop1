﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class BookingRepository : IBookingRepository
    {
        private readonly FoodDbContext _appDbContext;

        public BookingRepository(FoodDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Booking_Details> AllBooking
        {
            get
            {
                return _appDbContext.Booking.Include(r => r.Restaurants);
            }
        }

        public Booking_Details GetBooking_DetailsById(int BookingId)
        {
            return _appDbContext.Booking.FirstOrDefault(p => p.BookingId == BookingId);
        }
    }
}
