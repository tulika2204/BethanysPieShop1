export const environment = {
  production: false,
  appUrl: 'https://localhost:44382/'
  };