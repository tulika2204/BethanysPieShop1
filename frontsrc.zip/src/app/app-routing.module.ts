import { Routes, RouterModule } from '@angular/router';
import { AppComponent} from './app.component';
import { HomeComponent } from './home';
import { LoginComponent} from './login/login.component';
import { RegisterComponent} from './register/register.component';
import { AuthGuard } from './_gaurds';
const routes: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  {path: 'login', component:LoginComponent},
  {path: 'signup', component:RegisterComponent},
  { path: '**', redirectTo: '' }
];



export const routing = RouterModule.forRoot(routes);
