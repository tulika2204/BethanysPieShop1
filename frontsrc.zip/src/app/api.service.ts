import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from "@angular/common/http";
import { Observable, ObservedValueOf} from "rxjs";
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  SERVER_URL: string="http://localhost:8000/search/?format=json";
  httpHeaders = new HttpHeaders({"Content-Type": "application/json"});

  constructor(public http: HttpClient) { }

  public get(): Observable<any>{
    return this.http.get(this.SERVER_URL +"", {
      headers: this.httpHeaders
    });
  }
  public post(formData){
    let res = formData;
    return this.http.post<JSON>(this.SERVER_URL, res,{});
  }
 
}
