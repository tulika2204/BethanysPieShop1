import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { FoodService } from '../food/food.service';
import { Food } from '../_models/food';
@Component({
selector: 'app-food',
templateUrl: '../food/food.component.html',
styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
blogPosts$: Observable<Food[]>;
FoodId: number;
constructor(private blogPostService: FoodService, private avRoute:ActivatedRoute) {
  const idParam = 'id';
  if(this.avRoute.snapshot.params[idParam]){
    this.FoodId=this.avRoute.snapshot.params[idParam];
  }
}
ngOnInit() {
this.loadBlogPosts();
}
loadBlogPosts() {
this.blogPosts$ = this.blogPostService.getBlogPosts();
}
/*delete(FoodId) {
const ans = confirm('Do you want to delete blog post with id: ' + FoodId);
if (ans) {
this.blogPostService.deleteFood(FoodId).subscribe((data) => {
this.loadBlogPosts();
});
}
}*/
}