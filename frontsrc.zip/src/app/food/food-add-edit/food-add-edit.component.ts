import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { FoodService } from 'src/app/food/food.service';
import { Food } from 'src/app/food.component';
@Component({
selector: 'app-food-add-edit',
templateUrl: './food-add-edit.component.html',
styleUrls: ['./food-add-edit.component.css']
})
export class FoodAddEditComponent implements OnInit {
form: FormGroup;
actionType: string;
formTitle: string;
formBody: string;
FoodId: number;
errorMessage: any;
existingBlogPost: Food;
constructor(private blogPostService: FoodService,
private formBuilder: FormBuilder, private avRoute:
ActivatedRoute, private router: Router) {
const idParam = 'id';
this.actionType = 'Add';
this.formTitle = 'title';
this.formBody = 'body';
if (this.avRoute.snapshot.params[idParam]) {
this.FoodId = this.avRoute.snapshot.params[idParam];
}
this.form = this.formBuilder.group(
{
postId: 0,
title: ['', [Validators.required]],
body: ['', [Validators.required]],
}
)
}
ngOnInit() {
if (this.FoodId > 0) {
this.actionType = 'Edit';
this.blogPostService.getFood(this.FoodId).subscribe(data => (
this.existingBlogPost = data,
this.form.controls[this.formTitle].setValue(data.title),
this.form.controls[this.formBody].setValue(data.body)
));
}
}
save() {
if (!this.form.valid) {
return;
}
if (this.actionType === 'Add') {
let blogPost: Food = {
dt: new Date(),
creator: 'Martin',
title: this.form.get(this.formTitle).value,
body: this.form.get(this.formBody).value
};

}
}
cancel() {
this.router.navigate(['/']);
}
get title() { return this.form.get(this.formTitle); }
get body() { return this.form.get(this.formBody); }
}