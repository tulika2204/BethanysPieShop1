import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule }    from '@angular/forms';
import { fakeBackendProvider } from './_helpers';
//import { AppRoutingModule } from './app-routing.module';
import { routing }  from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CarouselComponent } from './carousel/carousel.component';
import { CardsComponent } from './cards/cards.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from 'src/app/login/login.component';
import { RegisterComponent  } from './register/register.component';
import {MaterialModule} from './material-module';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { FoodComponent } from './food/food.component';
import { HomeComponent } from './home/home.component';
import { AlertComponent } from './directives/alert/alert.component';
import { AuthGuard } from 'src/app/_gaurds';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AlertService, AuthenticationService, UserService } from './_services';
//import { FoodAddEditComponent } from '../food/food-add-edit/food-add-edit.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
  
    CarouselComponent,CardsComponent, FooterComponent, LoginComponent, RegisterComponent, FoodComponent, 
    HomeComponent, AlertComponent, //FoodAddEditComponent

  ],
  imports: [
    BrowserModule,
   routing,
    BrowserAnimationsModule,
    //MaterialModule,
    //FormsModule,
    ReactiveFormsModule,
HttpClientModule
  ],
  providers: [
    AuthGuard,
    AlertService,
    AuthenticationService,
    UserService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

    // provider used to create fake backend
    fakeBackendProvider
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
