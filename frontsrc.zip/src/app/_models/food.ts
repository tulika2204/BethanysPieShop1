

export class Food{
    FoodId : string;
    FoodName: string;
    FoodPrice: number;
    FoodImageUrl : string;
    FoodDesc : string;
}