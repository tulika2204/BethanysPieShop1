import { StreamPriorityOptions } from 'http2';

export class Restaurant{
    RestId: number;
    RestName: string;
    RestMenu: string;
    RestImageUrl : string;
    RestDesc : string;
    RestContactNumber: number;
}