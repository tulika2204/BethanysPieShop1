﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodSystem.Models;
using KitchenAPI.Models;

namespace FoodSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderCartsController : ControllerBase
    {
        private readonly FoodDbContext _context;

        public OrderCartsController(FoodDbContext context)
        {
            _context = context;
        }

        // GET: api/OrderCarts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderCart>>> GetOrderCart()
        {
            return await _context.OrderCart.ToListAsync();
        }

        // GET: api/OrderCarts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderCart>> GetOrderCart(string id)
        {
            var orderCart = await _context.OrderCart.FindAsync(id);

            if (orderCart == null)
            {
                return NotFound();
            }

            return orderCart;
        }

        // PUT: api/OrderCarts/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderCart(string id, OrderCart orderCart)
        {
            if (id != orderCart.OrderCartId)
            {
                return BadRequest();
            }

            _context.Entry(orderCart).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderCartExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OrderCarts
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<OrderCart>> PostOrderCart(OrderCart orderCart)
        {
            _context.OrderCart.Add(orderCart);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OrderCartExists(orderCart.OrderCartId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOrderCart", new { id = orderCart.OrderCartId }, orderCart);
        }

        // DELETE: api/OrderCarts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<OrderCart>> DeleteOrderCart(string id)
        {
            var orderCart = await _context.OrderCart.FindAsync(id);
            if (orderCart == null)
            {
                return NotFound();
            }

            _context.OrderCart.Remove(orderCart);
            await _context.SaveChangesAsync();

            return orderCart;
        }

        private bool OrderCartExists(string id)
        {
            return _context.OrderCart.Any(e => e.OrderCartId == id);
        }
    }
}
