﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class Booking_Details
    {
        [Key]
        public int BookingId { get; set; }
        public int RestId { get; set; }
        public Restaurants Restaurants { get; set; }
    }
}
