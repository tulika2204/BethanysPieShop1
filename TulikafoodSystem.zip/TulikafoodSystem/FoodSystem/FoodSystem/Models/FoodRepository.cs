﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class FoodRepository : IFoodRepository
    {
        private readonly FoodDbContext _appDbContext;

        public FoodRepository(FoodDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Food> AllFoods
        {
            get
            {
                return _appDbContext.Foods.Include(c => c.Category);
            }
        }



        public Food GetFoodById(int FoodId)
        {
            return _appDbContext.Foods.FirstOrDefault(p => p.FoodId == FoodId);
        }
    }

}
