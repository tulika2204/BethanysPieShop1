﻿using FoodSystem.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class Order
    {[Key]
        public int OrderId { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public decimal OrderTotal { get; set; }
        public DateTime OrderPlaced { get; set; }
        public List<OrderDetails> OrderDetail { get; internal set; }
        public int Address_Id { get; set; }
        public Address Address { get; set; }
    }
}
