﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BethanysPieShop.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "Pies",
                columns: table => new
                {
                    PieId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    ShortDescription = table.Column<string>(nullable: true),
                    LongDescription = table.Column<string>(nullable: true),
                    AllergyInformation = table.Column<string>(nullable: true),
                    Price = table.Column<decimal>(nullable: false),
                    ImageUrl = table.Column<string>(nullable: true),
                    ImageThumbnailUrl = table.Column<string>(nullable: true),
                    IsPieOfTheWeek = table.Column<bool>(nullable: false),
                    InStock = table.Column<bool>(nullable: false),
                    CategoryId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pies", x => x.PieId);
                    table.ForeignKey(
                        name: "FK_Pies_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[] { 1, "fruit Pies", null });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[] { 2, "Cheese Cakes", null });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[] { 3, "Seasonal Pies", null });

            migrationBuilder.InsertData(
                table: "Pies",
                columns: new[] { "PieId", "AllergyInformation", "CategoryId", "ImageThumbnailUrl", "ImageUrl", "InStock", "IsPieOfTheWeek", "LongDescription", "Name", "Price", "ShortDescription" },
                values: new object[,]
                {
                    { 1, "", 1, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 3, "", 1, "", "", true, true, "ygyugfyugfyuft", "choco Pie", 12.95m, "hegfuowgy" },
                    { 6, "", 1, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 9, "", 1, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 2, "", 2, "", "", true, true, "ygyugfyugfyuft", "Blueberry Cheese Cakes", 12.95m, "hegfuowgy" },
                    { 5, "", 2, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 7, "", 2, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 11, "", 2, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 13, "", 3, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 4, "", 3, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 8, "", 3, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" },
                    { 10, "", 3, "", "", true, true, "ygyugfyugfyuft", "Apple Pie", 12.95m, "hegfuowgy" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pies_CategoryId",
                table: "Pies",
                column: "CategoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pies");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
