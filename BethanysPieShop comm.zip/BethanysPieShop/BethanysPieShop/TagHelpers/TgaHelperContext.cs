﻿namespace BethanysPieShop.TagHelpers
{
    public class TgaHelperContext
    {
    }
}