﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrmApi.Model
{
    public class Order
    {
        public DateTimeOffset OrderDate { get; set; }
        public int OrderId { get;  set; }
    }
}
