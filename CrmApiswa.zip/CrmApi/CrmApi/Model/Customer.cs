﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrmApi.Model
{
    public class Customer
    {
        public string Address { get; set; }

        public int CustomerType { get; set; }
        public static int InstanceCount { get; set; }
    }
}
